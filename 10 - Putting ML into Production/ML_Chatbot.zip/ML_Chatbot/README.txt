This is an ML Chatbot which was created during the ML Course

The resources folder is for Desktop

The app folder is for Web with Flask