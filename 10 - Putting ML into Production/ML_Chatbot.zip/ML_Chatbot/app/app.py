import nltk
import numpy as np
import json
import random
from nltk.stem.lancaster import LancasterStemmer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import LabelEncoder
from flask import Flask, render_template

"""## Load the Intents File"""

with open("resources/mlchat_intents.json") as file:
	data = json.loads(file.read())

"""Extract the Data"""

docs_x = []
docs_y = []

stemmer = LancasterStemmer()
for intent in data['intents']:
	for pattern in intent['patterns']:
		wrds = nltk.word_tokenize(pattern)
		wrds = [stemmer.stem(w.lower()) for w in wrds if w != "?"]
		docs_x.append(' '.join(wrds))
		docs_y.append(intent["tag"])

"""Vectorize X"""

cv = CountVectorizer()
X = cv.fit_transform(docs_x).toarray()

"""Vectorize Y"""

le = LabelEncoder()
y = le.fit_transform(docs_y)

"""## Build and Train the Chatbot

Support Vector Machine
"""

from sklearn.svm import SVC
classifier = SVC(kernel='linear')
classifier.fit(X, y)

"""Predict Function"""

def provide_response(sent):
  #Pre-Process Input
  sent = nltk.word_tokenize(sent)
  sent = [stemmer.stem(w.lower()) for w in sent if w != "?"]
  sent = [' '.join(sent)]
  X_pred = cv.transform(sent).toarray()

  #Predict
  y_pred = classifier.predict(X_pred)
  tag = le.inverse_transform(y_pred)
  tag = tag[0]

  #Get the options to respond
  for tg in data['intents']:
    if tg['tag'] == tag:
      responses = tg['responses']

  #Return one of them
  return random.choice(responses)


app = Flask(__name__)

@app.route('/')
def hello_world():
	return render_template('ml_chat.html')
	
@app.route('/chat/<input>')
def process_chat(input):
	return provide_response(input)