$(document).ready(function(){
	$("#send_chat").on('click', function(){
		var inp = $("#conv").val(); 
		
		html = "<div class='person'><strong> YOU: </strong> " + inp + "</div>";
		$("#output_pane").append(html);
		
		$.ajax("/chat/" + inp).done(function(response){
			html = "<div class='robot'><strong> BOT: </strong> " + response + "</div>";
			$("#output_pane").append(html);
		});
		
	});
});