from os import path
import subprocess
import sys

if not path.exists("python/Scripts/pip.exe"):
	print("\nInitialising first time run...\n")
	subprocess.call([sys.executable, "resources/get-pip.py"])

reqs = subprocess.check_output([sys.executable, '-m', 'pip', 'freeze'])
installed = [r.decode().split('==')[0] for r in reqs.split()]

required = {'numpy', 'sklearn', 'nltk', 'flask'}  #Flask is only required for web based deployment
missing = required - set(installed)
if missing:
	subprocess.check_call([sys.executable, '-m', 'pip', 'install', *missing])

print("\nCompleted Installations...")